( function( $ ) {
	"use strict";

	if ( typeof google == 'undefined' )
		return;

	var mapStyles = {
		'subtle-grayscale': [{"featureType":"landscape","stylers":[{"saturation":-100},{"lightness":65},{"visibility":"on"}]},{"featureType":"poi","stylers":[{"saturation":-100},{"lightness":51},{"visibility":"simplified"}]},{"featureType":"road.highway","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"road.arterial","stylers":[{"saturation":-100},{"lightness":30},{"visibility":"on"}]},{"featureType":"road.local","stylers":[{"saturation":-100},{"lightness":40},{"visibility":"on"}]},{"featureType":"transit","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"administrative.province","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"on"},{"lightness":-25},{"saturation":-100}]},{"featureType":"water","elementType":"geometry","stylers":[{"hue":"#ffff00"},{"lightness":-25},{"saturation":-97}]}],
		'pale-dawn': [{"featureType":"administrative","elementType":"all","stylers":[{"visibility":"on"},{"lightness":33}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2e5d4"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#c5dac6"}]},{"featureType":"poi.park","elementType":"labels","stylers":[{"visibility":"on"},{"lightness":20}]},{"featureType":"road","elementType":"all","stylers":[{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#c5c6c6"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#e4d7c6"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#fbfaf7"}]},{"featureType":"water","elementType":"all","stylers":[{"visibility":"on"},{"color":"#acbcc9"}]}],
		'blue-warter': [{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#444444"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2f2f2"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#46bcec"},{"visibility":"on"}]}],
		'light-monochrome': [{"featureType":"administrative.locality","elementType":"all","stylers":[{"hue":"#2c2e33"},{"saturation":7},{"lightness":19},{"visibility":"on"}]},{"featureType":"landscape","elementType":"all","stylers":[{"hue":"#ffffff"},{"saturation":-100},{"lightness":100},{"visibility":"simplified"}]},{"featureType":"poi","elementType":"all","stylers":[{"hue":"#ffffff"},{"saturation":-100},{"lightness":100},{"visibility":"off"}]},{"featureType":"road","elementType":"geometry","stylers":[{"hue":"#bbc0c4"},{"saturation":-93},{"lightness":31},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"hue":"#bbc0c4"},{"saturation":-93},{"lightness":31},{"visibility":"on"}]},{"featureType":"road.arterial","elementType":"labels","stylers":[{"hue":"#bbc0c4"},{"saturation":-93},{"lightness":-2},{"visibility":"simplified"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"hue":"#e9ebed"},{"saturation":-90},{"lightness":-8},{"visibility":"simplified"}]},{"featureType":"transit","elementType":"all","stylers":[{"hue":"#e9ebed"},{"saturation":10},{"lightness":69},{"visibility":"on"}]},{"featureType":"water","elementType":"all","stylers":[{"hue":"#e9ebed"},{"saturation":-78},{"lightness":67},{"visibility":"simplified"}]}]
	};

	google.maps.event.addDomListener( window, 'load', function() {
		$( '.google-maps[id]' ).each( function() {
			try {
				var config = JSON.parse( $( this ).attr( 'data-config' ) );
				var locations = JSON.parse( $( this ).attr( 'data-locations' ) );
				var types  = {
					'roadmap'  : google.maps.MapTypeId.ROADMAP,
					'satellite': google.maps.MapTypeId.SATELLITE,
					'hybrid'   : google.maps.MapTypeId.HYBRID,
					'terrain'  : google.maps.MapTypeId.TERRAIN
				}

				var geocoder = new google.maps.Geocoder();
				var canvas   = this;

				geocoder.geocode( { 'address': config.address }, function( results, status ) {
					if ( status == google.maps.GeocoderStatus.OK ) {
						var mapOptions = {
							center     : results[0].geometry.location,
							zoom       : parseInt( config.zoomlevel || 12 ),
							mapTypeId  : types[config.type || 'roadmap'],
							scrollwheel: config.zoomable || false,
							styles     : mapStyles[config.style],

							panControl: true,
							scaleControl: true,
							streetViewControl: true,
							zoomControl: true,
							draggable: config.draggable || false
						};

						var map = new google.maps.Map( canvas,
		    				mapOptions );

						if ( config.show_marker == true ) {
							var marker = new google.maps.Marker({
								map: map,
								position: results[0].geometry.location,
								icon: config.marker
							});
						}

						if ( locations && config.show_marker == true ) {
							$.map( locations, function( value ) {
								geocoder.geocode( { 'address': value }, function( results, status ) {
									if ( results.length > 0 ) {
										var marker = new google.maps.Marker({
											map: map,
											position: results[0].geometry.location,
											icon: config.marker
										});
									}
								} );
							} );
						}
					}
				} );
			}
			catch( e ) {}
		} );
	} );

} ).call( this, jQuery );
